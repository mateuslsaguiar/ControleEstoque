## Controle de Estoque

### Introdução 

* Software sobre controle de estoque e vendas.

### Uso

* Compilação

1 - qmake controlestoque.pro

2 - make -f Makefile

### Exemplos

* Login: adm
senha : 123
* Login: cxa
senha : 3
* Login: cli
senha : cliente

### Orientação

* Prof. Dr. Ruben Carlo Benante
* Data: 2023-02-09
* Licensa: GNU/GPL v2.0

